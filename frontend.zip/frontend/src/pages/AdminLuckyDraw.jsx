import { useEffect, useRef, useState } from "react";
import {
  adminLogin,
  getLuckyDrawStatus,
  setLuckyDrawIncludeAllEntriesNextDraw,
  setLuckyDrawIncludeAllThisMonthEntriesNextDraw,
  setLuckyDrawVisibility,
  spinLuckyDraw,
  updateLuckyDrawFeatures,
} from "../services/api";
import { createClientId } from "../utils/createClientId";
import "../App.css";
import "./LuckyDraw.css";

function formatLast4Phone(phone) {
  const clean = (phone || "").replace(/\D/g, "");
  if (clean.length >= 4) {
    return `•••• ${clean.slice(-4)}`;
  }
  return "•••• 1234";
}

function normalizeDrawEntries(entries = []) {
  return entries.map((entry, index) => ({
    ...entry,
    id: String(entry.id ?? index),
    name: entry.name || "",
  }));
}

function AdminLuckyDraw() {
  const [entries, setEntries] = useState([]);
  const [adminToken, setAdminToken] = useState(
    () => window.localStorage.getItem("bnb-admin-token") || "",
  );
  const [credentials, setCredentials] = useState({ email: "", password: "" });
  const [adminError, setAdminError] = useState("");
  const [isDrawing, setIsDrawing] = useState(false);
  const [isSpinRequestInFlight, setIsSpinRequestInFlight] = useState(false);
  const spinRequestInFlightRef = useRef(false);
  const [showWheelOverlay, setShowWheelOverlay] = useState(false);
  const [winner, setWinner] = useState(null);
  const [showWinnerPopup, setShowWinnerPopup] = useState(false);
  const [whatsappLink, setWhatsappLink] = useState("");
  const [wheelEnabled, setWheelEnabled] = useState(false);
  const [manualDrawCompleted, setManualDrawCompleted] = useState(false);
  const [hasWinnerForCurrentCycle, setHasWinnerForCurrentCycle] =
    useState(false);
  const [customerVisibilityDecision, setCustomerVisibilityDecision] =
    useState(null);
  const [includeAllEntriesNextDraw, setIncludeAllEntriesNextDraw] =
    useState(false);
  const [
    includeAllThisMonthEntriesNextDraw,
    setIncludeAllThisMonthEntriesNextDraw,
  ] = useState(false);
  const [isUpdatingVisibility, setIsUpdatingVisibility] = useState(false);
  const [isUpdatingEligibilityReset, setIsUpdatingEligibilityReset] =
    useState(false);
  const [isUpdatingMonthEntries, setIsUpdatingMonthEntries] = useState(false);
  const [eligibilityRules, setEligibilityRules] = useState({
    annualEligibilityEnabled: true,
    previousWinnerExclusionEnabled: true,
  });
  const [isSavingEligibilityRules, setIsSavingEligibilityRules] =
    useState(false);
  const [isAdminStatusLoaded, setIsAdminStatusLoaded] = useState(false);

  useEffect(() => {
    if (!adminToken) return;
    setIsAdminStatusLoaded(false);
    getLuckyDrawStatus()
      .then((status) => {
        setWheelEnabled(status.wheelEnabled);
        if (typeof status.wheelEnabled === "boolean") {
          setCustomerVisibilityDecision(status.wheelEnabled);
        }
        const drawDone = Boolean(
          status.manualDrawCompleted || status.hasWinnerForCurrentCycle,
        );
        setManualDrawCompleted(drawDone);
        setHasWinnerForCurrentCycle(Boolean(status.hasWinnerForCurrentCycle));
        if (status.lastSpin?.winner) {
          const w = status.lastSpin.winner;
          setWinner((current) => current || {
            id: String(w.id ?? status.lastSpin.id ?? createClientId()),
            name: w.Name || w.name,
            phone: w.Phone || w.phone,
            date: w.date || w.dob || w["Date of birth"],
            occasion: w.occasion || w.Occasion || "Special Celebration",
          });
        }
        setIncludeAllEntriesNextDraw(
          status.includeAllEntriesNextDraw === true,
        );
        setIncludeAllThisMonthEntriesNextDraw(
          status.includeAllThisMonthEntriesNextDraw === true,
        );
        setEligibilityRules({
          annualEligibilityEnabled: status.annualEligibilityEnabled !== false,
          previousWinnerExclusionEnabled:
            status.previousWinnerExclusionEnabled !== false,
        });
        setEntries(normalizeDrawEntries(status.entries));
        setIsAdminStatusLoaded(true);
      })
      .catch((error) => {
        if (error.message === "Admin access is required") {
          window.localStorage.removeItem("bnb-admin-token");
          setAdminToken("");
          setEntries([]);
          return;
        }
        setAdminError(error.message || "Unable to load admin draw data");
      });
  }, [adminToken]);

  useEffect(() => {
    if (!adminToken || !isAdminStatusLoaded) return undefined;
    let isActive = true;

    const syncDrawStatus = async () => {
      try {
        const status = await getLuckyDrawStatus();
        if (!isActive) return;

        setEntries(normalizeDrawEntries(status.entries));
        setWheelEnabled(status.wheelEnabled);
        if (typeof status.wheelEnabled === "boolean") {
          setCustomerVisibilityDecision(status.wheelEnabled);
        }
        const drawDone = Boolean(
          status.manualDrawCompleted || status.hasWinnerForCurrentCycle,
        );
        setManualDrawCompleted(drawDone);
        setHasWinnerForCurrentCycle(Boolean(status.hasWinnerForCurrentCycle));
        setIncludeAllEntriesNextDraw(
          status.includeAllEntriesNextDraw === true,
        );
        setIncludeAllThisMonthEntriesNextDraw(
          status.includeAllThisMonthEntriesNextDraw === true,
        );
      } catch (error) {
        if (isActive) {
          handleAdminActionError(error, "Unable to refresh draw status");
        }
      }
    };

    const intervalId = window.setInterval(() => {
      if (isActive && document.visibilityState === "visible") {
        void syncDrawStatus();
      }
    }, 2500);

    window.addEventListener("focus", syncDrawStatus);
    return () => {
      isActive = false;
      window.clearInterval(intervalId);
      window.removeEventListener("focus", syncDrawStatus);
    };
  }, [adminToken, isAdminStatusLoaded]);

  const handleAdminActionError = (error, fallbackMessage) => {
    if (error.message === "Admin access is required") {
      window.localStorage.removeItem("bnb-admin-token");
      setAdminToken("");
      setAdminError("Your admin session has expired. Sign in again.");
      return;
    }
    setAdminError(error.message || fallbackMessage);
  };

  const handleAdminLogin = async (event) => {
    event.preventDefault();
    setAdminError("");
    try {
      const result = await adminLogin(credentials);
      setAdminToken(result.token);
      window.localStorage.setItem("bnb-admin-token", result.token);
      setCredentials({ email: "", password: "" });
      window.history.replaceState({}, "", "/admin");
    } catch (error) {
      setAdminError(error.message || "Unable to sign in as admin");
    }
  };

  const isCompletedOrHasWinner = Boolean(
    manualDrawCompleted ||
    hasWinnerForCurrentCycle ||
    winner,
  );

  const handleSpin = async (options = {}) => {
    const isRespin = Boolean(options?.isRespin || isCompletedOrHasWinner);

    if (
      !adminToken ||
      spinRequestInFlightRef.current ||
      (!isRespin && customerVisibilityDecision === null) ||
      isUpdatingVisibility ||
      isDrawing ||
      showWheelOverlay ||
      !entries.length
    ) {
      return;
    }

    // Immediately prevent multiple clicks and update UI to drawing mode
    spinRequestInFlightRef.current = true;
    setIsSpinRequestInFlight(true);
    setIsDrawing(true);
    setShowWinnerPopup(false);
    setAdminError("");
    let animationWillContinue = false;

    try {
      const result = await spinLuckyDraw(adminToken, { respin: isRespin });
      setManualDrawCompleted(true);
      const winnerEntry = {
        id: String(result.winner.id ?? result.spinId ?? createClientId()),
        name: result.winner.Name || result.winner.name,
        phone: result.winner.Phone || result.winner.phone,
        date:
          result.winner.date ||
          result.winner.dob ||
          result.winner["Date of birth"],
        occasion:
          result.winner.occasion ||
          result.winner.Occasion ||
          "Special Celebration",
      };
      setWinner(winnerEntry);
      try {
        window.localStorage.setItem("bnb-lucky-draw-latest-winner", JSON.stringify(winnerEntry));
      } catch {}
      setWhatsappLink(result.whatsapp?.chatLink || "");

      try {
        const updatedStatus = await getLuckyDrawStatus();
        setEntries(normalizeDrawEntries(updatedStatus.entries));
      } catch {}

      if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
        setIsDrawing(false);
        setShowWheelOverlay(false);
        setShowWinnerPopup(true);
        spinRequestInFlightRef.current = false;
        setWheelEnabled(false);
        setCustomerVisibilityDecision(false);
        return;
      }

      // Keep the entry animation visible before the wheel begins.
      animationWillContinue = true;
      if (window.matchMedia("(max-width: 768px)").matches) {
        window.setTimeout(() => {
          document
            .querySelector(".admin-draw-panel .name-capsule-grid")
            ?.scrollIntoView({ behavior: "smooth", block: "center" });
        }, 0);
      }
      setShowWheelOverlay(false);
      setShowWinnerPopup(false);

      // Start the wheel after the entry capsules have animated.
      window.setTimeout(() => {
        setShowWheelOverlay(true);
      }, 3500);

      // Match the wheel animation duration before showing the winner dialog.
      window.setTimeout(() => {
        setIsDrawing(false);
        setShowWheelOverlay(false);
        setShowWinnerPopup(true);
        spinRequestInFlightRef.current = false;
        setWheelEnabled(false);
        setCustomerVisibilityDecision(false);
      }, 9000);
    } catch (error) {
      setIsDrawing(false);
      spinRequestInFlightRef.current = false;
      handleAdminActionError(error, "Unable to run the lucky draw");
    } finally {
      setIsSpinRequestInFlight(false);
      if (!animationWillContinue) {
        spinRequestInFlightRef.current = false;
      }
    }
  };

  const handleCustomerVisibilityDecision = async (enabled) => {
    if (isUpdatingVisibility || isDrawing || isSpinRequestInFlight) {
      return;
    }
    setIsUpdatingVisibility(true);
    setAdminError("");
    try {
      const result = await setLuckyDrawVisibility(adminToken, enabled);
      setWheelEnabled(result.wheelEnabled);
      setCustomerVisibilityDecision(result.wheelEnabled);
    } catch (error) {
      handleAdminActionError(error, "Unable to update draw visibility");
    } finally {
      setIsUpdatingVisibility(false);
    }
  };

  const handleEligibilityReset = async () => {
    if (isUpdatingEligibilityReset || isDrawing || isSpinRequestInFlight) return;
    setIsUpdatingEligibilityReset(true);
    setAdminError("");
    try {
      const result = await setLuckyDrawIncludeAllEntriesNextDraw(
        adminToken,
        !includeAllEntriesNextDraw,
      );
      setIncludeAllEntriesNextDraw(result.includeAllEntriesNextDraw);
      if (result.includeAllEntriesNextDraw) {
        setIncludeAllThisMonthEntriesNextDraw(false);
      }
      try {
        const status = await getLuckyDrawStatus();
        setEntries(normalizeDrawEntries(status.entries));
      } catch (error) {
        setAdminError(
          `Eligibility reset saved, but entries could not be refreshed: ${error.message}`,
        );
      }
    } catch (error) {
      handleAdminActionError(error, "Unable to update next-draw eligibility");
    } finally {
      setIsUpdatingEligibilityReset(false);
    }
  };

  const handleIncludeThisMonthEntries = async () => {
    if (isUpdatingMonthEntries || isDrawing || isSpinRequestInFlight) return;
    setIsUpdatingMonthEntries(true);
    setAdminError("");
    try {
      const result = await setLuckyDrawIncludeAllThisMonthEntriesNextDraw(
        adminToken,
        !includeAllThisMonthEntriesNextDraw,
      );
      setIncludeAllThisMonthEntriesNextDraw(
        result.includeAllThisMonthEntriesNextDraw,
      );
      if (result.includeAllThisMonthEntriesNextDraw) {
        setIncludeAllEntriesNextDraw(false);
      }
      try {
        const status = await getLuckyDrawStatus();
        setEntries(normalizeDrawEntries(status.entries));
      } catch (error) {
        setAdminError(
          `Monthly entries option saved, but entries could not be refreshed: ${error.message}`,
        );
      }
    } catch (error) {
      handleAdminActionError(error, "Unable to update this month's entries");
    } finally {
      setIsUpdatingMonthEntries(false);
    }
  };

  const handleEligibilityRuleChange = (field, value) => {
    setEligibilityRules((current) => ({ ...current, [field]: value }));
  };

  const handleSaveEligibilityRules = async () => {
    setIsSavingEligibilityRules(true);
    setAdminError("");

    try {
      const settings = await updateLuckyDrawFeatures(adminToken, {
        annualEligibilityEnabled: eligibilityRules.annualEligibilityEnabled,
        previousWinnerExclusionEnabled:
          eligibilityRules.previousWinnerExclusionEnabled,
      });
      setEligibilityRules({
        annualEligibilityEnabled: settings.annualEligibilityEnabled !== false,
        previousWinnerExclusionEnabled:
          settings.previousWinnerExclusionEnabled !== false,
      });
      try {
        const status = await getLuckyDrawStatus();
        setEntries(normalizeDrawEntries(status.entries));
      } catch (error) {
        setAdminError(
          `Rules saved, but eligible entries could not be refreshed: ${error.message}`,
        );
      }
    } catch (error) {
      handleAdminActionError(error, "Unable to save eligibility rules");
    } finally {
      setIsSavingEligibilityRules(false);
    }
  };

  const renderSharedDrawOptions = () => (
    <section className="admin-draw-common-options" aria-label="Shared draw options">
      <div className="admin-draw-step">
        <div className="admin-draw-step-heading">
          <span>Step 1</span>
          <h2>Eligibility rules <small>(Optional)</small></h2>
        </div>
        <fieldset
          className="admin-feature-settings admin-eligibility-rules"
          disabled={isSavingEligibilityRules || isDrawing || isSpinRequestInFlight}
        >
          <legend>Who can enter this draw?</legend>
          <label className="admin-feature-toggle">
            <span>
              <strong>Annual entry eligibility</strong>
              <small>
                Limit each phone number to one eligible entry every 12 months.
              </small>
            </span>
            <input
              type="checkbox"
              checked={eligibilityRules.annualEligibilityEnabled}
              onChange={(event) =>
                handleEligibilityRuleChange(
                  "annualEligibilityEnabled",
                  event.target.checked,
                )
              }
            />
          </label>
          <label className="admin-feature-toggle">
            <span>
              <strong>Previous winner exclusion</strong>
              <small>Exclude customers who won within the last 12 months.</small>
            </span>
            <input
              type="checkbox"
              checked={eligibilityRules.previousWinnerExclusionEnabled}
              onChange={(event) =>
                handleEligibilityRuleChange(
                  "previousWinnerExclusionEnabled",
                  event.target.checked,
                )
              }
            />
          </label>
          <button
            className="admin-save-draw-setup"
            disabled={isSavingEligibilityRules || isDrawing || isSpinRequestInFlight}
            onClick={handleSaveEligibilityRules}
            type="button"
          >
            {isSavingEligibilityRules ? "Saving eligibility..." : "Save eligibility rules"}
          </button>
        </fieldset>
      </div>

      <div className="admin-draw-step">
        <div className="admin-draw-step-heading">
          <span>Step 2</span>
          <h2>Entry overrides <small>(Optional)</small></h2>
        </div>
        <div className="admin-eligibility-reset">
          <div>
            <strong>
              {includeAllEntriesNextDraw
                ? "Next draw includes all registered customers"
                : "Recent winners are excluded"}
            </strong>
            <small>
              {includeAllEntriesNextDraw
                ? "The one-time reset clears automatically after the next draw."
                : "Include recent winners in the next draw only."}
            </small>
          </div>
          <button
            className="admin-eligibility-reset-button"
            disabled={
              isUpdatingEligibilityReset || isDrawing || isSpinRequestInFlight
            }
            onClick={handleEligibilityReset}
            type="button"
          >
            {isUpdatingEligibilityReset
              ? "Updating..."
              : includeAllEntriesNextDraw
                ? "Cancel next-draw reset"
                : "Include everyone in next draw"}
          </button>
        </div>
        <div className="admin-eligibility-reset">
          <div>
            <strong>
              {includeAllThisMonthEntriesNextDraw
                ? "This draw uses celebrations happening this month"
                : "Include only this month's celebrations"}
            </strong>
            <small>
              {includeAllThisMonthEntriesNextDraw
                ? "One entry per customer with a celebration date this month, including recent winners."
                : "Include customers with a celebration date this month, even if they are recent winners."}
            </small>
          </div>
          <button
            className="admin-eligibility-reset-button"
            disabled={isUpdatingMonthEntries || isDrawing || isSpinRequestInFlight}
            onClick={handleIncludeThisMonthEntries}
            type="button"
          >
            {isUpdatingMonthEntries
              ? "Updating..."
              : includeAllThisMonthEntriesNextDraw
                ? "Cancel this-month celebrations"
                : "Include this month's celebrations"}
          </button>
        </div>
      </div>

      <div className="admin-draw-step">
        <div className="admin-draw-step-heading">
          <span>Step 3</span>
          <h2>Customer visibility <small>(Mandatory)</small></h2>
        </div>
        <fieldset
          className="admin-feature-settings admin-customer-visibility"
          disabled={isUpdatingVisibility || isDrawing || isSpinRequestInFlight}
        >
          <legend>Enable the draw for customers?</legend>
          <p>
            Choose whether the lucky draw is visible on the customer site.
          </p>
          <label className="admin-feature-toggle">
            <span>
              <strong>Yes</strong>
              <small>Make the draw visible to customers.</small>
            </span>
            <input
              type="radio"
              name="customer-draw-visibility"
              value="yes"
              checked={customerVisibilityDecision === true}
              onChange={() => handleCustomerVisibilityDecision(true)}
            />
          </label>
          <label className="admin-feature-toggle">
            <span>
              <strong>No</strong>
              <small>Keep the draw hidden from customers.</small>
            </span>
            <input
              type="radio"
              name="customer-draw-visibility"
              value="no"
              checked={customerVisibilityDecision === false}
              onChange={() => handleCustomerVisibilityDecision(false)}
            />
          </label>
          <p className="admin-visibility-status" role="status">
            <span
              className={`status-dot ${wheelEnabled ? "is-live" : "is-hidden"}`}
            ></span>
            <span>
              Current status:{" "}
              <strong>
                {wheelEnabled ? "Live for customers" : "Hidden from customers"}
              </strong>
            </span>
          </p>
        </fieldset>
      </div>
    </section>
  );

  if (!adminToken) {
    return (
      <main className="admin-login-page">
        <form className="admin-login-card" onSubmit={handleAdminLogin}>
          <a className="admin-login-brand" href="/" aria-label="Binge & Bliss home">
            <img src="/landing_page/logo.jpg" alt="Binge & Bliss" />
            <span>Binge &amp; Bliss</span>
            <small>ADMIN PORTAL</small>
          </a>
          <p className="admin-access-title">Admin access</p>
          <h1>Sign in to continue</h1>
          <p className="admin-login-description">
            Enter your admin credentials to access the draw dashboard.
          </p>
          <input
            type="email"
            value={credentials.email}
            onChange={(event) =>
              setCredentials((current) => ({
                ...current,
                email: event.target.value,
              }))
            }
            placeholder="Admin email"
            aria-label="Admin email"
            autoComplete="username"
            required
          />
          <input
            type="password"
            value={credentials.password}
            onChange={(event) =>
              setCredentials((current) => ({
                ...current,
                password: event.target.value,
              }))
            }
            placeholder="Admin password"
            aria-label="Admin password"
            autoComplete="current-password"
            required
          />
          <button className="dark-button" type="submit">
            Sign in to continue <span>↗</span>
          </button>
          {adminError && (
            <p className="form-error" role="alert">
              {adminError}
            </p>
          )}
        </form>
      </main>
    );
  }

  return (
    <main className="admin-shell">
      <aside className="admin-sidebar" aria-label="Admin navigation">
        <a className="admin-brand" href="/" aria-label="Binge N Bliss home">
          <img src="/landing_page/logo.jpg" alt="Binge N Bliss" />
          <span>BNB admin</span>
        </a>
        <nav className="admin-nav">
          <a className="is-active" href="#spin-wheel">
            Spin wheel
          </a>
          <a href="/admin/occasions">Special occasions</a>
          <a href="/admin/customers">Customers</a>
          <a href="/admin/winner-history">Winner history</a>
          <a href="/lucky-draw">Customer site</a>
        </nav>
        {adminToken && (
          <button
            className="admin-signout"
            onClick={() => {
              window.localStorage.removeItem("bnb-admin-token");
              window.location.href = "/admin";
            }}
            type="button"
          >
            Sign out
          </button>
        )}
      </aside>
      <section className="admin-main" id="admin-lucky-draw">
        <div className="admin-page-heading">
          <span className="heading-tag">Monthly Draw</span>
          <span className="heading-title">Choose a winner.</span>
          <span className="heading-divider">•</span>
          <span className="heading-sub">
            Choose one winner from the saved customer entries.
          </span>
        </div>
        <div className="admin-draw-layout" id="spin-wheel">
          <div className="admin-draw-panel">
            <span className="admin-access-title">
              Admin draw control
            </span>
            <section className="admin-draw-tab-panel is-manual" id="draw-tab-panel">
              {renderSharedDrawOptions()}
              <div className="admin-draw-step">
                <div className="admin-draw-step-heading">
                  <span>Step 4</span>
                  <h2>Manual spin</h2>
                </div>
                <section
                  className="admin-draw-widget is-unlocked"
                  aria-label="Lucky draw widget"
                  aria-disabled={customerVisibilityDecision === null}
                >
                  <div className="lucky-draw-reveal-panel">
                    <span className="draw-reveal-kicker">
                      Manual Winner Selection
                    </span>
                    <strong className={isDrawing ? "is-drawing" : ""}>
                      {isDrawing
                        ? "Selecting Winner..."
                        : winner
                          ? winner.name
                          : "Ready when you are"}
                    </strong>
                    <div
                      className="name-capsule-grid"
                      aria-label="Lucky draw customers"
                    >
                      {entries.map((entry, index) => {
                        const displayName =
                          entry.name ?? entry.Name ?? "Unknown";
                        const isWinner =
                          !isDrawing &&
                          (winner?.name ?? winner?.Name ?? "") === displayName;
                        return (
                          <span
                            className={[
                              "name-capsule",
                              isWinner ? "is-winner" : "",
                              isDrawing ? "is-blinking" : "",
                            ]
                              .filter(Boolean)
                              .join(" ")}
                            key={entry.id}
                            style={{
                              animationDelay: `${(index * 79) % 900}ms`,
                            }}
                          >
                            {displayName}
                          </span>
                        );
                      })}
                    </div>
                    <small>
                      {entries.length} eligible entries in this month&apos;s draw
                    </small>
                  </div>
                  <button
                    id="admin-start-spin-button"
                    className={`draw-button ${isDrawing || isSpinRequestInFlight ? "is-running" : ""}`}
                    disabled={
                      isCompletedOrHasWinner ||
                      isSpinRequestInFlight ||
                      customerVisibilityDecision === null ||
                      isUpdatingVisibility ||
                      isDrawing ||
                      !entries.length
                    }
                    style={{
                      pointerEvents:
                        isCompletedOrHasWinner ||
                        isSpinRequestInFlight ||
                        customerVisibilityDecision === null ||
                        isUpdatingVisibility ||
                        isDrawing ||
                        !entries.length
                          ? "none"
                          : "auto",
                      opacity:
                        isCompletedOrHasWinner ||
                        isSpinRequestInFlight ||
                        customerVisibilityDecision === null ||
                        isUpdatingVisibility ||
                        isDrawing ||
                        !entries.length
                          ? 0.7
                          : 1,
                      cursor:
                        isCompletedOrHasWinner ||
                        isSpinRequestInFlight ||
                        customerVisibilityDecision === null ||
                        isUpdatingVisibility ||
                        isDrawing ||
                        !entries.length
                          ? "not-allowed"
                          : "pointer",
                    }}
                    onClick={handleSpin}
                    type="button"
                  >
                    <span>
                      {isDrawing
                        ? "Selecting Winner..."
                        : isCompletedOrHasWinner
                          ? "Draw Complete"
                          : isSpinRequestInFlight
                            ? "Starting Draw..."
                            : customerVisibilityDecision === null
                              ? "Choose Yes or No to continue"
                              : "Start / Run the Draw"}
                    </span>
                    <span className="btn-arrow">→</span>
                  </button>
                  {isCompletedOrHasWinner && (
                    <div className="admin-respin-container">
                      <button
                        id="admin-respin-button"
                        className="admin-respin-button"
                        onClick={() => handleSpin({ isRespin: true })}
                        disabled={
                          isDrawing ||
                          isSpinRequestInFlight ||
                          !entries.length
                        }
                        type="button"
                      >
                        <span className="respin-icon">🔄</span>
                        <span>
                          {isDrawing
                            ? "Selecting New Winner..."
                            : isSpinRequestInFlight
                              ? "Starting Re-spin..."
                              : "Re-spin (Choose Another Winner)"}
                        </span>
                        <span className="btn-arrow">→</span>
                      </button>
                      <p className="admin-respin-hint">
                        💡 <strong>Re-spin option:</strong> Use if the winner is unavailable, for festival special draws, or testing. Selects another winner from remaining eligible entries.
                      </p>
                    </div>
                  )}
                  <p className="admin-redraw-note">
                    One winner is selected per customer-visibility session.
                    To start a new draw, turn customer visibility off and
                    enable it again.
                  </p>
                </section>
              </div>
            </section>
            {adminError && (
              <p className="form-error" role="alert">
                {adminError}
              </p>
            )}
          </div>
        </div>
      </section>
      {/* Full Screen Spinning Wheel Overlay Blocking Screen */}
      {showWheelOverlay && (
        <div
          className="spinning-wheel-full-overlay"
          role="dialog"
          aria-modal="true"
        >
          <div className="spinning-wheel-stage">
            <div className="wheel-crown-header">👑</div>

            <div className="wheel-stage-container">
              {/* Pointer at top (Stationary) */}
              <div className="wheel-top-pointer">▼</div>

              {/* Smooth Spinning Wheel Rotator */}
              <div className="wheel-svg-rotator is-spinning">
                <svg
                  viewBox="0 0 300 300"
                  width="300"
                  height="300"
                  className="wheel-svg-graphic"
                >
                  {/* Outer Rim Shadow & Glow */}
                  <circle cx="150" cy="150" r="146" fill="#be185d" />
                  <circle cx="150" cy="150" r="138" fill="#e879f9" />

                  {/* 8 Segments */}
                  <g>
                    <path
                      d="M150 150 L150 15 A135 135 0 0 1 245.45 54.55 Z"
                      fill="#fbcfe8"
                    />
                    <path
                      d="M150 150 L245.45 54.55 A135 135 0 0 1 285 150 Z"
                      fill="#f3e8ff"
                    />
                    <path
                      d="M150 150 L285 150 A135 135 0 0 1 245.45 245.45 Z"
                      fill="#fef08a"
                    />
                    <path
                      d="M150 150 L245.45 245.45 A135 135 0 0 1 150 285 Z"
                      fill="#e0e7ff"
                    />
                    <path
                      d="M150 150 L150 285 A135 135 0 0 1 54.55 245.45 Z"
                      fill="#fbcfe8"
                    />
                    <path
                      d="M150 150 L54.55 245.45 A135 135 0 0 1 15 150 Z"
                      fill="#f3e8ff"
                    />
                    <path
                      d="M150 150 L15 150 A135 135 0 0 1 54.55 54.55 Z"
                      fill="#fef08a"
                    />
                    <path
                      d="M150 150 L54.55 54.55 A135 135 0 0 1 150 15 Z"
                      fill="#e0e7ff"
                    />
                  </g>

                  {/* Segment Divider Lines */}
                  <g stroke="#ffffff" strokeWidth="3" opacity="0.85">
                    <line x1="150" y1="150" x2="150" y2="15" />
                    <line x1="150" y1="150" x2="245.45" y2="54.55" />
                    <line x1="150" y1="150" x2="285" y2="150" />
                    <line x1="150" y1="150" x2="245.45" y2="245.45" />
                    <line x1="150" y1="150" x2="150" y2="285" />
                    <line x1="150" y1="150" x2="54.55" y2="245.45" />
                    <line x1="150" y1="150" x2="15" y2="150" />
                    <line x1="150" y1="150" x2="54.55" y2="54.55" />
                  </g>

                  {/* Outer Lights / Bulbs */}
                  {[
                    0, 22.5, 45, 67.5, 90, 112.5, 135, 157.5, 180, 202.5, 225,
                    247.5, 270, 292.5, 315, 337.5,
                  ].map((angle, idx) => {
                    const rad = (angle * Math.PI) / 180;
                    const cx = 150 + 141.5 * Math.sin(rad);
                    const cy = 150 - 141.5 * Math.cos(rad);
                    return (
                      <circle
                        key={idx}
                        cx={cx}
                        cy={cy}
                        r="4.5"
                        fill={idx % 2 === 0 ? "#ffffff" : "#fef08a"}
                        stroke="#be185d"
                        strokeWidth="1.5"
                      />
                    );
                  })}

                  {/* Center Cap */}
                  <circle cx="150" cy="150" r="32" fill="#be185d" />
                  <circle cx="150" cy="150" r="26" fill="#ec4899" />
                  <circle cx="150" cy="150" r="20" fill="#f472b6" />
                  <circle
                    cx="144"
                    cy="144"
                    r="6"
                    fill="#ffffff"
                    opacity="0.7"
                  />
                </svg>
              </div>

              {/* Pedestal Stand (Stationary at bottom) */}
              <div className="wheel-pedestal-stand">
                <div className="pedestal-top"></div>
                <div className="pedestal-base"></div>
              </div>
            </div>

            <div className="spinning-wheel-status">
              <h2>Spinning the Lucky Wheel...</h2>
              <p>Selecting this month&apos;s lucky draw winner!</p>
            </div>
          </div>
        </div>
      )}

      {/* Smooth Winner Card Modal Overlaid on 3D Template Poster */}
      {showWinnerPopup && winner && (
        <div
          className="winner-popup-backdrop"
          onClick={() => setShowWinnerPopup(false)}
          role="presentation"
        >
          <div
            className="winner-template-modal-card"
            onClick={(event) => event.stopPropagation()}
            role="dialog"
            aria-modal="true"
            aria-labelledby="admin-winner-popup-title"
          >
            <button
              className="winner-template-close-btn"
              onClick={() => setShowWinnerPopup(false)}
              type="button"
              aria-label="Close winner announcement"
            >
              ×
            </button>

            {/* Poster Graphic with Text Overlays */}
            <div className="template-poster-wrapper">
              <img
                src="/lucky_draw_registration/winner_card_template.png"
                alt="Winner Announcement Template"
                className="template-poster-img"
              />

              <div className="template-overlay-layer">
                {/* Occasion Ribbon Text - Winner Name */}
                <svg
                  className="overlay-ribbon-text"
                  viewBox="0 0 100 32"
                  role="img"
                  aria-label={`Winner: ${winner.name}`}
                >
                  <defs>
                    <path
                      id="admin-winner-name-curve"
                      d="M 8 27 Q 50 5 92 27"
                    />
                  </defs>
                  <text>
                    <textPath
                      href="#admin-winner-name-curve"
                      xlinkHref="#admin-winner-name-curve"
                      startOffset="50%"
                      textAnchor="middle"
                      textLength="82"
                      lengthAdjust="spacingAndGlyphs"
                    >
                      {winner.name}
                    </textPath>
                  </text>
                </svg>

                {/* Slot 2: Celebration Date */}
                <div className="overlay-slot slot-date">
                  <span className="slot-label">Celebration Date</span>
                  <strong className="slot-value">
                    {winner.date || winner.dob || "Upcoming Celebration"}
                  </strong>
                </div>

                {/* Slot 3: Occasion */}
                <div className="overlay-slot slot-occasion">
                  <span className="slot-label">Occasion</span>
                  <strong className="slot-value">
                    {winner.occasion || "Special Celebration"}
                  </strong>
                </div>

                {/* Slot 4: Phone Number */}
                <div className="overlay-slot slot-phone">
                  <span className="slot-label">
                    Phone Number (Last 4 Digits)
                  </span>
                  <strong className="slot-value">
                    {formatLast4Phone(winner.phone)}
                  </strong>
                </div>
              </div>
            </div>

            {/* Action Buttons at bottom */}
            <div className="template-card-footer-actions">
              {whatsappLink ? (
                <a
                  className="winner-claim-btn whatsapp-action-btn"
                  href={whatsappLink}
                  target="_blank"
                  rel="noreferrer"
                >
                  Send WhatsApp Notification <span>↗</span>
                </a>
              ) : null}
              <button
                id="admin-modal-respin-btn"
                className="winner-respin-secondary-btn"
                onClick={() => {
                  setShowWinnerPopup(false);
                  handleSpin({ isRespin: true });
                }}
                type="button"
                disabled={isDrawing || isSpinRequestInFlight || !entries.length}
              >
                🔄 Re-spin (New Winner)
              </button>
              <button
                className="winner-claim-btn"
                onClick={() => setShowWinnerPopup(false)}
                type="button"
              >
                Close Poster <span>✨</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}

export default AdminLuckyDraw;
