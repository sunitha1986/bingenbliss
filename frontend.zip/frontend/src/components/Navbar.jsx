import { useState } from "react";

function Navbar({
  user,
  onLogin,
  onLogout,
  standalone = false,
  luckyDrawBanner,
}) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      {luckyDrawBanner && (
        <div className="nav-draw-banner">
          <div className="nav-draw-banner-inner">
            <div className="banner-main-row">
              <div className="banner-brand-pill" aria-label="Binge N Bliss">
                <span className="banner-brand-crown" aria-hidden="true">
                  ♛
                </span>
                <span>
                  Binge<span className="banner-brand-highlight">N</span>Bliss
                </span>
              </div>
              <span
                className="banner-gift banner-gift-left"
                aria-hidden="true"
              >
                <span className="banner-gift-bow" />
                <span className="banner-gift-lid" />
                <span className="banner-gift-box" />
              </span>
              <div className="banner-headline" aria-label="Lucky Draw">
                <span className="banner-lucky">LUCKY</span>
                <span className="banner-draw">DRAW</span>
              </div>
              <span
                className="banner-gift banner-gift-right"
                aria-hidden="true"
              >
                <span className="banner-gift-bow" />
                <span className="banner-gift-lid" />
                <span className="banner-gift-box" />
              </span>
              <a
                className="banner-cta"
                href="/lucky-draw"
                target="_blank"
                rel="noopener noreferrer"
              >
                Enter Lucky Draw
              </a>
              <span className="banner-spark banner-spark-left" aria-hidden="true">
                ✦
              </span>
              <span
                className="banner-spark banner-spark-mid-left"
                aria-hidden="true"
              >
                ✦
              </span>
              <span
                className="banner-spark banner-spark-mid-right"
                aria-hidden="true"
              >
                ✦
              </span>
              <span
                className="banner-spark banner-spark-right"
                aria-hidden="true"
              >
                ✦
              </span>
            </div>
            <div
              className="banner-ticker"
              role="region"
              aria-label="Lucky draw updates"
            >
              <div className="banner-ticker-track">
                {[0, 1].map((copy) => (
                  <span
                    className="banner-ticker-copy"
                    aria-hidden={copy === 1 ? "true" : undefined}
                    key={copy}
                  >
                    <span>
                      Latest winner:{" "}
                      {luckyDrawBanner.winnerName || "To be announced"}
                    </span>
                    {luckyDrawBanner.winnerMonth && (
                      <span>({luckyDrawBanner.winnerMonth})</span>
                    )}
                    <span className="banner-ticker-star" aria-hidden="true">
                      ✦
                    </span>
                    <span>
                      Next month&apos;s Lucky Draw:{" "}
                      {luckyDrawBanner.nextDrawDate || "Date to be announced"}
                    </span>
                    <span className="banner-ticker-star" aria-hidden="true">
                      ✦
                    </span>
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
      <nav className="nav-bar" aria-label="Main navigation">
        <a className="brand" href="/" aria-label="Binge N Bliss home">
          <img src="/landing_page/logo.jpg" alt="Binge N Bliss" />
        </a>

        <button
          aria-label="Toggle navigation menu"
          aria-expanded={menuOpen}
          className="nav-toggle"
          onClick={() => setMenuOpen((open) => !open)}
          type="button"
        >
          <span />
          <span />
          <span />
        </button>

        <div className={`nav-links ${menuOpen ? "open" : ""}`}>
          <a href={standalone ? "/" : "#top"} onClick={() => setMenuOpen(false)}>
            Home
          </a>
          {!standalone && (
            <a href="#events" onClick={() => setMenuOpen(false)}>
              Events
            </a>
          )}
          {!standalone && (
            <a href="#gallery" onClick={() => setMenuOpen(false)}>
              Gallery
            </a>
          )}
          {!standalone && (
            <a href="#contact" onClick={() => setMenuOpen(false)}>
              Contact
            </a>
          )}
          <a
            className="lucky-draw-nav-button"
            href="/lucky-draw"
            onClick={() => setMenuOpen(false)}
            rel="noopener noreferrer"
            target="_blank"
          >
            LuckyDraw
          </a>
          {!standalone &&
            (user ? (
              <button
                className="account-button"
                onClick={() => {
                  setMenuOpen(false);
                  onLogout?.();
                }}
                type="button"
              >
                Sign out
              </button>
            ) : (
              <button
                className="account-button"
                onClick={() => {
                  setMenuOpen(false);
                  onLogin?.();
                }}
                type="button"
              >
                Log in
              </button>
            ))}
        </div>
      </nav>
    </>
  );
}

export default Navbar;
